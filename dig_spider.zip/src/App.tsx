import { useEffect, useRef, useState } from "react"
import { createCrawler } from "./crawler"

const LINKS = [
  { t: "什么是网络爬虫？", u: "https://zh.wikipedia.org/wiki/%E7%B6%B2%E8%B7%AF%E7%88%AC%E8%9F%B2" },
  { t: "Google 搜索中心：抓取与索引", u: "https://developers.google.com/search/docs/crawling-indexing" },
  { t: "MDN：robots.txt 是什么", u: "https://developer.mozilla.org/zh-CN/docs/Glossary/Robots.txt" },
  { t: "Common Crawl：开放网页数据集", u: "https://commoncrawl.org/" },
  { t: "MDN：requestAnimationFrame", u: "https://developer.mozilla.org/zh-CN/docs/Web/API/Window/requestAnimationFrame" },
  { t: "蜘蛛如何用八条腿行走？", u: "https://en.wikipedia.org/wiki/Spider#Locomotion" },
]
const TEXT = [
  "The crawler wakes at dusk and wanders the page, reading nothing yet touching every word.",
  "Each leg searches for a foothold, a single syllable to grip, before the body dares to move forward.",
  "Paragraphs become terrain. Headlines are ridges, margins are cliffs, and punctuation is loose gravel underfoot.",
  "It never rests for long. Somewhere further down there is another sentence worth stepping on.",
  "Indexing, parsing, following links: the old work of spiders, rendered here as eight patient limbs.",
]

type P = { x: number; y: number }

const Words = ({ text }: { text: string }) =>
  text.split(" ").map((w, i) => (
    <span key={i}>
      <span data-w className="crawl-word">{w}</span>{" "}
    </span>
  ))

// Defined at module scope so its identity is stable; an inline component would
// unmount/remount its whole subtree on every App render.
const Toggle = ({ label, hint, on, set }: { label: string; hint: string; on: boolean; set: (v: boolean) => void }) => (
  <button
    role="switch"
    aria-checked={on}
    onClick={() => set(!on)}
    className="flex w-full items-center justify-between gap-5 rounded-lg px-3 py-2.5 text-left hover:bg-[#0aa344]/8"
  >
    <span>
      <span className="block text-sm text-[#0b3d2c]">{label}</span>
      <span className="block text-[11px] text-[#758a99]">{hint}</span>
    </span>
    <span className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? "bg-[#0aa344]" : "bg-[#c9d3cf]"}`}>
      <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all ${on ? "left-[18px]" : "left-0.5"}`} />
    </span>
  </button>
)

export default function App() {
  const canvas = useRef<HTMLCanvasElement>(null)
  const root = useRef<HTMLDivElement>(null)
  const [menu, setMenu] = useState<P | null>(null)
  const [popup, setPopup] = useState<(P & { t: string; u: string; k: number }) | null>(null)
  const [enabled, setEnabled] = useState(true)
  const [follow, setFollow] = useState(true)
  const [exportModal, setExportModal] = useState(false)
  const [downloading, setDownloading] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  // Any runtime error on the site switches the crawler's breathing light to amber.
  const [issue, setIssue] = useState<string | null>(null)
  const ctl = useRef({ enabled: true, follow: false, menuOpen: false, alert: false })

  const downloadBlobFile = async (url: string, filename: string) => {
    try {
      setDownloading(filename)
      const res = await fetch(url)
      if (!res.ok) throw new Error("Fetch failed: " + res.status)
      const blob = await res.blob()
      const blobUrl = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = blobUrl
      a.download = filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      setTimeout(() => URL.revokeObjectURL(blobUrl), 10000)
    } catch (err) {
      window.open(url, "_blank")
    } finally {
      setDownloading(null)
    }
  }

  const copyHtmlSource = async () => {
    try {
      const res = await fetch("/spider-crawler.html")
      const text = await res.text()
      await navigator.clipboard.writeText(text)
      setCopied(true)
      setTimeout(() => setCopied(false), 3000)
    } catch (err) {
      window.open("/spider-crawler.html", "_blank")
    }
  }
  ctl.current.alert = !!issue
  ctl.current.enabled = enabled
  ctl.current.follow = follow
  ctl.current.menuOpen = !!menu

  useEffect(() => {
    const onErr = (e: ErrorEvent) => setIssue(e.message || "运行时错误")
    const onRej = (e: PromiseRejectionEvent) => setIssue(String(e.reason?.message ?? e.reason ?? "未处理的异步错误"))
    addEventListener("error", onErr)
    addEventListener("unhandledrejection", onRej)
    return () => {
      removeEventListener("error", onErr)
      removeEventListener("unhandledrejection", onRej)
    }
  }, [])

  useEffect(() => {
    if (!popup) return
    const id = setTimeout(() => setPopup(null), 9000)
    return () => clearTimeout(id)
  }, [popup])

  useEffect(
    () =>
      createCrawler({
        canvas: canvas.current!,
        root: root.current!,
        ctl,
        onMenu: (x, y) => setMenu({ x: Math.min(x + 14, innerWidth - 244), y: Math.min(y + 14, innerHeight - 150) }),
        onFart: () => {
          setMenu(null)
        },
        onNewsClicked: (newsIdx, x, y) => {
          setMenu(null)
          const l = LINKS[newsIdx % LINKS.length]
          const px = Math.max(12, Math.min(innerWidth - 280, x - 130))
          const py = Math.max(12, Math.min(innerHeight - 120, y - 90))
          setPopup({ ...l, k: Date.now(), x: px, y: py })
        },
      }),
    [],
  )

  return (
    <div className="tech-bg" translate="no">
      <header data-ui className="hud-bar fixed inset-x-0 top-0 z-30 flex items-center justify-between px-6 py-3 font-mono text-[10px] tracking-[0.28em] text-[#3d5566]">
        <span className="flex items-center gap-3">
          <span className="hud-mark" />
          CRAWLER://INDEX
        </span>
        <span className="hidden sm:inline">NODE 01 · LAT 0.27s · 8 LEGS</span>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setExportModal(true)}
            className="hidden items-center gap-1.5 rounded border border-[#0aa344]/45 bg-[#0aa344]/10 px-3 py-1 text-[10px] font-bold text-[#0aa344] transition-colors hover:bg-[#0aa344]/20 sm:flex"
            title="打开导出与下载面板"
          >
            <span>EXPORT // 源码与HTML下载</span>
            <span>↓</span>
          </button>
          <span className={`flex items-center gap-2 ${issue ? "text-[#d98a00]" : "text-[#0b1e2d]"}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${issue ? "status-amber" : "status-white"}`} />
            {issue ? "ISSUE · 待修复" : "ONLINE"}
          </span>
        </div>
      </header>
      <div className="hud-frame pointer-events-none fixed inset-4 z-10" />
      <div ref={root} className="relative mx-auto max-w-3xl select-none px-8 pb-24 pt-32 font-mono">
        <p className="mb-5 text-[11px] tracking-[0.4em] text-[#0aa344]">
          <Words text="[ AUTONOMOUS INDEXING UNIT ]" />
        </p>
        <h1 className="mb-14 text-6xl font-bold tracking-tight text-[#0b1e2d]">
          <Words text="The Web Crawler" />
        </h1>
        {[0, 1, 2].map((s) => (
          <section key={s} className="mb-16">
            <h2 className="section-rule mb-6 flex items-center gap-4 text-[11px] tracking-[0.35em] text-[#0aa344]">
              <span><Words text={`SECTION 0${s + 1}`} /></span>
            </h2>
            {TEXT.map((p, j) => (
              <p key={j} className="mb-8 text-xl leading-loose">
                <Words text={p} />
              </p>
            ))}
          </section>
        ))}

        {/* 关联资讯列表：蜘蛛双击放屁后将自主爬取并代为点击 */}
        <section className="mt-20 border-t border-[#0aa344]/25 pt-10">
          <h2 className="section-rule mb-6 flex items-center gap-4 text-[11px] tracking-[0.35em] text-[#0aa344]">
            <span><Words text="INDEXED DISPATCH // 关联资讯" /></span>
          </h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {LINKS.map((link, idx) => (
              <a
                key={idx}
                href={link.u}
                target="_blank"
                rel="noreferrer"
                data-news-link={idx}
                className="news-card group block rounded-xl border border-[#0aa344]/30 bg-white/90 p-4 font-mono transition-all duration-300 hover:border-[#0aa344] hover:shadow-[0_4px_24px_rgba(10,163,68,0.2)]"
              >
                <div className="flex items-center justify-between text-[10px] tracking-[0.2em] text-[#0aa344]">
                  <span>DISPATCH_0{idx + 1}</span>
                  <span className="text-[#758a99] group-hover:text-[#0aa344]">OPEN ↗</span>
                </div>
                <div className="mt-2 text-sm font-bold text-[#0b1e2d] transition-colors group-hover:text-[#0aa344]">
                  <Words text={link.t} />
                </div>
              </a>
            ))}
          </div>
        </section>

        {/* 源码与独立 HTML 导出下载面板 */}
        <section className="mt-16 rounded-2xl border border-[#0aa344]/35 bg-white/95 p-6 shadow-[0_10px_34px_rgba(10,163,68,0.12)]">
          <div className="flex items-center justify-between border-b border-[#0aa344]/20 pb-3 text-[11px] tracking-[0.25em] text-[#0aa344]">
            <span>EXPORT & SOURCE // 开发产物与源码下载</span>
            <span className="text-[10px] text-[#758a99]">V1.0.0 RELEASE</span>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col justify-between rounded-xl border border-[#0aa344]/40 bg-[#0aa344]/5 p-4">
              <div>
                <div className="flex items-center justify-between text-[10px] text-[#0aa344]">
                  <span>STANDALONE HTML</span>
                  <span className="rounded bg-[#0aa344]/15 px-1.5 py-0.5 font-bold">单文件离线版</span>
                </div>
                <div className="mt-2 text-sm font-bold text-[#0b1e2d]">
                  spider-crawler.html (约 460 KB)
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-[#758a99]">
                  内联全部 CSS、JS 与动画引擎，双击即可直接在任何现代浏览器中离线运行，无需 Node.js 环境。
                </p>
              </div>
              <div className="mt-4 flex flex-wrap gap-2 pt-2 border-t border-[#0aa344]/20">
                <button
                  onClick={() => downloadBlobFile("/spider-crawler.html", "spider-crawler.html")}
                  className="flex-1 rounded-lg bg-[#0aa344] px-3 py-2 text-center text-xs font-bold text-white shadow-sm transition hover:bg-[#0aa344]/90"
                >
                  {downloading === "spider-crawler.html" ? "下载中..." : "一键下载 HTML ↓"}
                </button>
                <button
                  onClick={copyHtmlSource}
                  className="rounded-lg border border-[#0aa344]/40 bg-white px-3 py-2 text-center text-xs text-[#0b3d2c] transition hover:bg-[#0aa344]/10"
                >
                  {copied ? "已复制源码！" : "复制源码"}
                </button>
                <a
                  href="/spider-crawler.html"
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-lg border border-[#758a99]/40 bg-white px-3 py-2 text-center text-xs text-[#758a99] transition hover:text-[#0b1e2d]"
                  title="新窗口打开后按 Ctrl+S 即可保存"
                >
                  新窗口打开 ↗
                </a>
              </div>
            </div>

            <div className="flex flex-col justify-between rounded-xl border border-[#758a99]/40 bg-[#758a99]/5 p-4">
              <div>
                <div className="flex items-center justify-between text-[10px] text-[#758a99]">
                  <span>SOURCE ARCHIVE</span>
                  <span className="rounded bg-[#758a99]/15 px-1.5 py-0.5 font-bold">完整工程源码</span>
                </div>
                <div className="mt-2 text-sm font-bold text-[#0b1e2d]">
                  spider-crawler-source.zip (约 300 KB)
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-[#758a99]">
                  包含全部 TypeScript 源码、步态动力学算法、Tailwind 样式、工程配置与 package.json。
                </p>
              </div>
              <div className="mt-4 flex flex-wrap gap-2 pt-2 border-t border-[#758a99]/20">
                <button
                  onClick={() => downloadBlobFile("/spider-crawler-source.zip", "spider-crawler-source.zip")}
                  className="flex-1 rounded-lg bg-[#2c4050] px-3 py-2 text-center text-xs font-bold text-white shadow-sm transition hover:bg-[#1a2b38]"
                >
                  {downloading === "spider-crawler-source.zip" ? "下载中..." : "一键下载源码 ZIP ↓"}
                </button>
                <a
                  href="/spider-crawler-source.zip"
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-lg border border-[#758a99]/40 bg-white px-3 py-2 text-center text-xs text-[#758a99] transition hover:text-[#0b1e2d]"
                >
                  直接打开下载 ↗
                </a>
              </div>
            </div>
          </div>
        </section>
      </div>
      <div className="tech-scan pointer-events-none fixed inset-0" />
      <canvas ref={canvas} className="pointer-events-none fixed inset-0 z-40 h-full w-full" />

      {menu && (
        <>
          <div data-ui className="fixed inset-0 z-50" onPointerDown={() => setMenu(null)} />
          <div
            data-ui
            className="fixed z-50 w-60 animate-[pop_.2s_ease-out] rounded-xl border border-[#0aa344]/35 bg-white/95 p-1.5 font-mono shadow-[0_10px_34px_rgba(10,163,68,0.18)] backdrop-blur"
            style={{ left: menu.x, top: menu.y }}
          >
            <div className="flex items-center gap-2 px-3 pb-1 pt-1.5 text-[10px] tracking-[0.25em] text-[#0aa344]">
              <span className={`h-1.5 w-1.5 rounded-full ${issue ? "status-amber" : "status-white"}`} />
              CRAWLER_01
            </div>
            {issue && (
              <div className="mx-3 mb-1 flex items-center justify-between gap-2 rounded-md border border-[#f0a020]/50 bg-[#fff6e0] px-2.5 py-1.5 text-[11px] text-[#9a5b00]">
                <span className="truncate" title={issue}>{`资讯异常：${issue}`}</span>
                <button onClick={() => setIssue(null)} className="shrink-0 underline underline-offset-2">已修复</button>
              </div>
            )}
            <Toggle label="蜘蛛功效" hint="开启或关闭蜘蛛功效" on={enabled} set={(v) => { setEnabled(v); if (!v) setMenu(null) }} />
            <Toggle label="跟随蜘蛛划动网页" hint="开启或关闭跟随蜘蛛划动网页" on={follow} set={setFollow} />
            <div className="mt-1.5 border-t border-[#0aa344]/20 pt-1.5 px-2">
              <div className="mb-1 text-[9px] text-[#758a99] tracking-[0.2em]">EXPORT // 导出下载</div>
              <div className="flex gap-2">
                <button
                  onClick={() => { setMenu(null); setExportModal(true); }}
                  className="w-full rounded border border-[#0aa344]/45 bg-[#0aa344]/10 px-2 py-1.5 text-center text-[10px] font-bold text-[#0aa344] hover:bg-[#0aa344]/20"
                >
                  打开下载与源码面板 ↓
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {popup && (
        <div
          key={popup.k}
          data-ui
          className="fixed z-50 w-64 animate-[pop_.25s_ease-out] rounded-xl border border-[#0aa344]/35 bg-white p-3 font-mono shadow-[0_10px_34px_rgba(10,163,68,0.2)]"
          style={{ left: popup.x, top: popup.y }}
        >
          <div className="mb-1.5 flex items-center justify-between text-[10px] tracking-[0.25em] text-[#0aa344]">
            <span>{"> 蜘蛛已代为点击资讯"}</span>
            <button onClick={() => setPopup(null)} className="px-1 text-base leading-none text-[#758a99] hover:text-[#0b3d2c]" aria-label="关闭">
              ×
            </button>
          </div>
          <a href={popup.u} target="_blank" rel="noreferrer" className="text-sm text-[#0b3d2c] underline decoration-[#0aa344] underline-offset-4 hover:text-[#0aa344]">
            {`${popup.t} →`}
          </a>
        </div>
      )}

      {!enabled && (
        <button
          data-ui
          onClick={() => setEnabled(true)}
          className="fixed bottom-6 right-6 z-50 rounded-full border border-[#0aa344]/45 bg-white px-4 py-2 font-mono text-sm text-[#0b3d2c] shadow-[0_4px_20px_rgba(10,163,68,0.2)] hover:bg-[#0aa344]/10"
        >
          启动爬虫
        </button>
      )}

      {/* 专用导出与多重下载模态窗 */}
      {exportModal && (
        <div data-ui className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-[pop_.2s_ease-out]">
          <div className="relative w-full max-w-lg rounded-2xl border border-[#0aa344]/40 bg-white p-6 font-mono shadow-[0_20px_60px_rgba(10,163,68,0.25)]">
            <div className="flex items-center justify-between border-b border-[#0aa344]/20 pb-3">
              <span className="text-xs font-bold tracking-[0.2em] text-[#0aa344]">
                CRAWLER EXPORT // 文件与源码下载
              </span>
              <button
                onClick={() => setExportModal(false)}
                className="text-base text-[#758a99] hover:text-[#0b1e2d]"
              >
                ✕
              </button>
            </div>

            <p className="mt-3 text-xs leading-relaxed text-[#758a99]">
              由于预览沙箱环境安全限制，若直接点击下载被拦截，您可使用以下任意备用方案获取文件：
            </p>

            <div className="mt-4 space-y-3">
              {/* HTML 下载 */}
              <div className="rounded-xl border border-[#0aa344]/30 bg-[#0aa344]/5 p-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0b1e2d]">方案一：单文件独立版 HTML</span>
                  <span className="text-[10px] text-[#0aa344]">约 460 KB</span>
                </div>
                <p className="mt-1 text-[11px] text-[#758a99]">
                  包含全部样式与动画逻辑，双击直接运行。
                </p>
                <div className="mt-2.5 flex gap-2">
                  <button
                    onClick={() => downloadBlobFile("/spider-crawler.html", "spider-crawler.html")}
                    className="flex-1 rounded-lg bg-[#0aa344] px-3 py-1.5 text-xs font-bold text-white transition hover:bg-[#0aa344]/90"
                  >
                    {downloading === "spider-crawler.html" ? "生成下载中..." : "直接下载 ↓"}
                  </button>
                  <button
                    onClick={copyHtmlSource}
                    className="rounded-lg border border-[#0aa344]/40 bg-white px-3 py-1.5 text-xs text-[#0b3d2c] transition hover:bg-[#0aa344]/10"
                  >
                    {copied ? "已复制到剪贴板！" : "一键复制完整源码"}
                  </button>
                  <a
                    href="/spider-crawler.html"
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-lg border border-[#758a99]/40 bg-white px-3 py-1.5 text-xs text-[#758a99] transition hover:text-[#0b1e2d]"
                  >
                    新窗口打开 ↗
                  </a>
                </div>
              </div>

              {/* ZIP 源码下载 */}
              <div className="rounded-xl border border-[#758a99]/30 bg-[#758a99]/5 p-3.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#0b1e2d]">方案二：完整开发源码包 ZIP</span>
                  <span className="text-[10px] text-[#758a99]">约 300 KB</span>
                </div>
                <p className="mt-1 text-[11px] text-[#758a99]">
                  包含全部 TypeScript 源码、Vite 构建配置及资源。
                </p>
                <div className="mt-2.5 flex gap-2">
                  <button
                    onClick={() => downloadBlobFile("/spider-crawler-source.zip", "spider-crawler-source.zip")}
                    className="flex-1 rounded-lg bg-[#2c4050] px-3 py-1.5 text-xs font-bold text-white transition hover:bg-[#1a2b38]"
                  >
                    {downloading === "spider-crawler-source.zip" ? "生成下载中..." : "直接下载 ZIP ↓"}
                  </button>
                  <a
                    href="/spider-crawler-source.zip"
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-lg border border-[#758a99]/40 bg-white px-3 py-1.5 text-xs text-[#758a99] transition hover:text-[#0b1e2d]"
                  >
                    在新窗口打开下载 ↗
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-4 rounded-lg bg-amber-500/10 p-2.5 text-[11px] text-[#9a5b00]">
              提示：若浏览器阻止下载，可在新窗口打开页面后，直接按下 <strong>Ctrl + S</strong>（Mac 上按 <strong>Cmd + S</strong>）将页面保存为 HTML 文件！
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
