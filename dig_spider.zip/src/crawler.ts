export type CrawlerCtl = { enabled: boolean; follow: boolean; menuOpen: boolean; alert: boolean }
export type CrawlerOpts = {
  canvas: HTMLCanvasElement
  root: HTMLElement
  ctl: { current: CrawlerCtl }
  onMenu: (x: number, y: number) => void
  onFart: (x: number, y: number) => void
  onNewsClicked?: (newsIdx: number, x: number, y: number) => void
  onSilkStatus?: (secRemaining: number) => void
}

type P = { x: number; y: number }
type Pose = P & { a: number }
type Word = { x: number; y: number; w: number; h: number; el: HTMLElement }
type Hold = { w: Word; p: P }
type Wp = P & { dur: number; l0: number; l1: number; arc: number; tap: boolean }
type Leg = {
  k: number; side: number; group: number; L: number
  x: number; y: number; lift: number
  state: "planted" | "swing" | "feel"
  path: Wp[]; seg: number; fx: number; fy: number; t: number; delay: number; hold: number
  el: HTMLElement | null; u: number; v: number
  next: { el: HTMLElement; u: number; v: number } | null
  slack: number; nextSlack: number
}

const PALETTE = ["#c32136", "#0aa344", "#ca6924", "#758a99"]
const COLOR_CONFIG: Record<string, { bg: string; glow: string; outline: string }> = {
  "#c32136": {
    bg: "rgba(195, 33, 54, 0.25)",
    glow: "rgba(195, 33, 54, 0.55)",
    outline: "rgba(195, 33, 54, 0.45)",
  },
  "#0aa344": {
    bg: "rgba(10, 163, 68, 0.25)",
    glow: "rgba(10, 163, 68, 0.55)",
    outline: "rgba(10, 163, 68, 0.45)",
  },
  "#ca6924": {
    bg: "rgba(202, 105, 36, 0.26)",
    glow: "rgba(202, 105, 36, 0.55)",
    outline: "rgba(202, 105, 36, 0.45)",
  },
  "#758a99": {
    bg: "rgba(117, 138, 153, 0.28)",
    glow: "rgba(117, 138, 153, 0.55)",
    outline: "rgba(117, 138, 153, 0.45)",
  },
}
// Front legs longest, rear legs shortest.
const LEG_L = [88, 82, 76, 70]
// Rest direction of each pair, measured from the heading toward its own side.
const ANG = [0.5, 1.16, 1.98, 2.62]
// Hip sockets around the cephalothorax (local x forward, y toward the side).
const HIP: [number, number][] = [[18, 5.2], [13.5, 7.1], [8.5, 7.3], [3.5, 5.2]]
const REST = 0.7
const SNAP = 24
const MAX_LEG_EXTENSION = 2.4
// Metachronal wave: front leg leads first with aggressive forward reach
const STAGGER = [0, 0.015, 0.03, 0.045]
const BREATH_T = 2.6
const SPEED = 280
const STEP_H = 1 / 60
const SILK_COOLDOWN = 180 // 3 minutes cooldown in seconds

const rnd = (a: number, b: number) => a + Math.random() * (b - a)
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v))
const dist = (a: P, b: P) => Math.hypot(a.x - b.x, a.y - b.y)
const angDiff = (a: number, b: number) => Math.atan2(Math.sin(a - b), Math.cos(a - b))
const smoother = (t: number) => t * t * t * (t * (t * 6 - 15) + 10)
const breath = (t: number) => Math.pow((1 - Math.cos((2 * Math.PI * t) / BREATH_T)) / 2, 1.6)
const rectDist = (w: Word, x: number, y: number) =>
  Math.hypot(Math.max(w.x - x, 0, x - w.x - w.w), Math.max(w.y - y, 0, y - w.y - w.h))
const clampIn = (w: Word, x: number, y: number): P => ({
  x: w.w > 8 ? clamp(x, w.x + 3, w.x + w.w - 3) : w.x + w.w / 2,
  y: clamp(y, w.y + w.h * 0.22, w.y + w.h * 0.78),
})

export function createCrawler({ canvas, root, ctl, onMenu, onFart, onNewsClicked, onSilkStatus }: CrawlerOpts) {
  const ctx = canvas.getContext("2d")!
  const S = innerWidth < 640 ? 0.78 : 1
  let words: Word[] = []

  const legs: Leg[] = []
  for (const side of [-1, 1])
    for (let k = 0; k < 4; k++)
      legs.push({
        k, side, group: (k + (side < 0 ? 0 : 1)) % 2, L: LEG_L[k] * S,
        x: 0, y: 0, lift: 0, state: "planted", path: [], seg: 0, fx: 0, fy: 0, t: 0, delay: 0, hold: 0,
        el: null, u: 0.5, v: 0.5, next: null, slack: 0, nextSlack: 0,
      })

  const body = { x: 0, y: 0, a: 0, v: 0, w: 0 }
  let spawned = false

  // ---------- word footholds + highlight ----------
  // Strictly enforce: ONLY words under currently planted feet are highlighted!
  type HeldInfo = { n: number; color: string }
  const held = new Map<HTMLElement, HeldInfo>()
  let paletteIdx = 0

  const grab = (el: HTMLElement | null, _x?: number, _y?: number) => {
    if (!el) return
    let h = held.get(el)
    if (!h) {
      const color = PALETTE[paletteIdx % PALETTE.length]
      paletteIdx++
      const cfg = COLOR_CONFIG[color] ?? {
        bg: "rgba(10, 163, 68, 0.25)",
        glow: "rgba(10, 163, 68, 0.5)",
      }
      el.style.setProperty("--hc", color)
      el.style.setProperty("--hc-bg", cfg.bg)
      el.style.setProperty("--hc-glow", cfg.glow)
      el.classList.add("is-hit")
      held.set(el, { n: 1, color })
    } else {
      h.n++
      el.classList.add("is-hit")
    }
  }

  const drop = (el: HTMLElement | null) => {
    if (!el) return
    const h = held.get(el)
    if (!h) return
    h.n = Math.max(0, h.n - 1)
    if (h.n === 0) {
      el.classList.remove("is-hit")
      held.delete(el)
    }
  }

  // Strict synchronization: strip is-hit from any word no longer under a planted foot!
  const syncHeldWords = () => {
    const activeEls = new Set<HTMLElement>()
    for (const l of legs) {
      if (l.state === "planted" && l.el) {
        activeEls.add(l.el)
      }
    }
    held.forEach((_, el) => {
      if (!activeEls.has(el)) {
        el.classList.remove("is-hit")
        held.delete(el)
      }
    })
    for (const el of activeEls) {
      if (!held.has(el)) {
        grab(el)
      }
    }
  }

  const dropAll = () => {
    held.forEach((_, el) => el.classList.remove("is-hit"))
    held.clear()
    legs.forEach((l) => (l.el = null))
  }
  const rectOf = (el: HTMLElement): Word => {
    const r = el.getBoundingClientRect()
    return { x: r.left + scrollX, y: r.top + scrollY, w: r.width, h: r.height, el }
  }

  const measure = () => {
    canvas.width = innerWidth * devicePixelRatio
    canvas.height = innerHeight * devicePixelRatio
    words = [...root.querySelectorAll<HTMLElement>("[data-w]")].map(rectOf)
    // keep planted feet glued to their word after reflow
    for (const l of legs)
      if (l.el && l.state === "planted") {
        const w = rectOf(l.el)
        l.x = w.x + l.u * w.w
        l.y = w.y + l.v * w.h
      }
  }
  const wordAt = (x: number, y: number) => words.some((w) => rectDist(w, x, y) < 2)

  // ---------- pose helpers ----------
  const hipAt = (l: Leg, p: Pose): P => {
    const c = Math.cos(p.a), s = Math.sin(p.a)
    const hx = HIP[l.k][0] * S, hy = HIP[l.k][1] * S * l.side
    return { x: p.x + c * hx - s * hy, y: p.y + s * hx + c * hy }
  }
  const restDir = (l: Leg, p: Pose) => p.a + l.side * ANG[l.k]
  const restAt = (l: Leg, p: Pose): P => {
    const h = hipAt(l, p), d = restDir(l, p)
    return { x: h.x + Math.cos(d) * REST * l.L, y: h.y + Math.sin(d) * REST * l.L }
  }
  const predict = (h: number): Pose => {
    const a = body.a + body.w * h
    const am = (body.a + a) / 2
    return { x: body.x + Math.cos(am) * body.v * h, y: body.y + Math.sin(am) * body.v * h, a }
  }
  const desired = (l: Leg, h: number) => {
    const pose = predict(h)
    const r = restAt(l, pose)
    // Front pair leads slightly, but stays naturally proportioned
    const isFront = l.k === 0
    const reachMult = isFront ? 0.72 : l.k === 1 ? 0.64 : 0.56
    const ahead = Math.min(body.v * (isFront ? 0.20 : 0.16), reachMult * l.L)
    return { x: r.x + Math.cos(pose.a) * ahead, y: r.y + Math.sin(pose.a) * ahead, pose }
  }

  const foothold = (l: Leg, d: P, pose: Pose): Hold => {
    const hip = hipAt(l, pose), rd = restDir(l, pose)
    const lo = 0.36 * l.L
    const hi = LEG_L[l.k] * S * MAX_LEG_EXTENSION
    let best = null as Hold | null, bs = Infinity
    let fallback = null as Hold | null, fbs = Infinity
    let nearest = null as Hold | null, nbs = Infinity
    for (const w of words) {
      const p = clampIn(w, d.x, d.y)
      const dd = dist(p, d)
      if (dd < nbs) { nbs = dd; nearest = { w, p } }

      if (rectDist(w, hip.x, hip.y) > hi) continue
      for (const q of [d, hip]) {
        const pt = clampIn(w, q.x, q.y)
        const dh = dist(pt, hip)
        if (dh > hi || dh < lo) continue
        const ddist = dist(pt, d)
        if (ddist < fbs) { fbs = ddist; fallback = { w, p: pt } }
        const da = Math.abs(angDiff(Math.atan2(pt.y - hip.y, pt.x - hip.x), rd))
        if (da > 2.2) continue
        const sc = ddist + da * 10
        if (sc < bs) { bs = sc; best = { w, p: pt } }
      }
    }
    return best ?? fallback ?? nearest ?? { w: words[0], p: clampIn(words[0], d.x, d.y) }
  }

  const need = (l: Leg) => {
    const dh = dist(l, hipAt(l, body))
    if (dh > 0.88 * l.L || dh < 0.45 * l.L) return 9
    return Math.max(0, dist(l, desired(l, 0.25)) - l.slack) / l.L
  }

  // ---------- stepping ----------
  const ripples: { x: number; y: number; t: number }[] = []
  const wp = (p: P, dur: number, arc: number, tap: boolean, l0 = 0, l1 = 0): Wp => ({ x: p.x, y: p.y, dur, arc, tap, l0, l1 })

  const startStep = (l: Leg, dur: number, delay: number, minNeed: number) => {
    const n = need(l)
    if (n < minNeed) return false
    const d = desired(l, dur + delay)
    const fh = foothold(l, d, d.pose)
    if (!fh) return false
    const requiredReach = dist(fh.p, hipAt(l, d.pose))
    const maxReach = LEG_L[l.k] * S * MAX_LEG_EXTENSION
    // Keep a small bend at full extension so the single knee joint remains visible.
    l.L = Math.max(l.L, Math.min(maxReach, requiredReach / 0.92))
    l.next = { el: fh.w.el, u: (fh.p.x - fh.w.x) / fh.w.w, v: (fh.p.y - fh.w.y) / fh.w.h }
    l.nextSlack = dist(fh.p, d)
    const onText = dist(fh.p, d) < SNAP || wordAt(d.x, d.y)
    const sc = S
    const liftArc = (l.k === 0 ? 12 : 9) * sc
    if (onText) {
      // Target is a word: land directly, never probe.
      l.path = [wp(fh.p, dur, liftArc, false)]
    } else {
      // Target is blank: touch down briefly in air, then settle firmly on the word foothold.
      l.path = [wp(d, dur * 0.7, liftArc * 0.85, true)]
      if (Math.random() < 0.45) {
        const b2 = { x: d.x + (fh.p.x - d.x) * 0.45 + rnd(-6, 6), y: d.y + (fh.p.y - d.y) * 0.45 + rnd(-6, 6) }
        if (!wordAt(b2.x, b2.y) && dist(b2, fh.p) > 10) l.path.push(wp(b2, 0.16, 7 * sc, true))
      }
      l.path.push(wp(fh.p, dur * 0.75, liftArc * 0.7, false))
    }
    drop(l.el)
    l.el = null
    l.state = "swing"; l.seg = 0; l.t = 0; l.fx = l.x; l.fy = l.y; l.delay = delay; l.hold = 0
    return true
  }

  const startFeel = (l: Leg) => {
    const f = { x: Math.cos(body.a), y: Math.sin(body.a) }
    const o = { x: -f.y * l.side, y: f.x * l.side }
    const s = S
    const p1 = { x: l.x + f.x * 22 * s + o.x * 4 * s, y: l.y + f.y * 22 * s + o.y * 4 * s }
    const p2 = { x: p1.x + o.x * 12 * s - f.x * 3 * s, y: p1.y + o.y * 12 * s - f.y * 3 * s }
    const p3 = { x: p1.x - o.x * 6 * s + f.x * 5 * s, y: p1.y - o.y * 6 * s + f.y * 5 * s }
    const lift = 15 * s
    l.path = [
      wp(p1, 0.5, 3, false, 0, lift),
      wp(p2, 0.42, 3, false, lift, lift),
      wp(p3, 0.42, 3, false, lift, lift),
      wp({ x: l.x, y: l.y }, 0.48, 2, false, lift, 0),
    ]
    l.state = "feel"; l.seg = 0; l.t = 0; l.fx = l.x; l.fy = l.y; l.delay = 0; l.hold = 0
  }

  const updateLegs = (dt: number) => {
    for (const l of legs) {
      if (l.state === "planted") continue
      if (l.delay > 0) { l.delay -= dt; continue }
      if (l.hold > 0) { l.hold -= dt; continue }
      const w = l.path[l.seg]
      l.t = Math.min(1, l.t + dt / w.dur)
      const e = smoother(l.t)
      l.x = l.fx + (w.x - l.fx) * e
      l.y = l.fy + (w.y - l.fy) * e
      l.lift = w.l0 + (w.l1 - w.l0) * e + Math.sin(Math.PI * l.t) * w.arc
      if (l.t < 1) continue
      l.fx = l.x; l.fy = l.y; l.t = 0; l.seg++
      // Blank-space probes are pass-through motions: make a ripple, but never
      // pause there. A leg is only planted after it reaches a word foothold.
      if (w.tap) ripples.push({ x: l.x, y: l.y, t: 0 })
      if (l.seg >= l.path.length) {
        if (l.state === "swing" && l.next) {
          l.el = l.next.el; l.u = l.next.u; l.v = l.next.v; l.next = null
          l.slack = l.nextSlack * 0.9
          grab(l.el, l.x, l.y)
        }
        l.state = "planted"; l.lift = 0
      }
    }
  }

  // ---------- behaviour ----------
  let mode: "walk" | "pause" | "fart" | "silk" | "hunt-news" = "walk", modeT = 12
  let target: P = { x: 0, y: 0 }
  let active = -1, lastGroup = 1, gaitGap = 0, sf = 1, feelCd = 0.6, feelSide = 0, antAmp = 0.3
  let fartT = 0, gasOut = false, popped = false
  let huntingNews: { el: HTMLElement; idx: number; pos: P } | null = null
  const gas: { x: number; y: number; vx: number; vy: number; r: number; t: number; life: number }[] = []

  // Spider silk swing: max once every 3 minutes (180s cooldown)
  let silkCd = SILK_COOLDOWN
  type SilkSwing = {
    phase: "shoot" | "swing" | "land"
    t: number
    dur: number
    from: P
    to: P
    anchor: P
    word: Word
    arc: number
    silkLen: number
    sparks: { x: number; y: number; vx: number; vy: number; t: number; life: number }[]
  }
  let silk: SilkSwing | null = null

  const startSilkSwing = (w: Word) => {
    if (mode === "silk" || silkCd > 0 || !spawned) return
    dropAll()
    const tx = w.x + w.w / 2, ty = w.y + w.h / 2
    const d = dist(body, { x: tx, y: ty })
    const arcHeight = Math.max(50, Math.min(180, d * 0.22))
    silk = {
      phase: "shoot",
      t: 0,
      dur: 0.28,
      from: { x: body.x, y: body.y },
      to: { x: tx, y: ty },
      anchor: { x: tx, y: ty - 12 },
      word: w,
      arc: arcHeight,
      silkLen: 0,
      sparks: [],
    }
    mode = "silk"
  }

  const pickTarget = () => {
    if (!words.length) return
    const follow = ctl.current.follow

    // When silk is off cooldown, actively scan for far text to swing to!
    if (silkCd <= 0 && spawned) {
      const farWords = words.filter((w) => {
        const d = Math.hypot(w.x + w.w / 2 - body.x, w.y + w.h / 2 - body.y)
        return d > 380 && d < 1600
      })
      if (farWords.length > 0) {
        const chosen = farWords[(Math.random() * farWords.length) | 0]
        target = { x: chosen.x + chosen.w / 2, y: chosen.y + chosen.h / 2 }
        startSilkSwing(chosen)
        return
      }
    }

    // Normal target: pick across paragraphs or sections
    let c = words.filter((w) => {
      const d = Math.hypot(w.x + w.w / 2 - body.x, w.y + w.h / 2 - body.y)
      if (d < 160) return false
      return follow ? true : w.y > scrollY + 90 && w.y < scrollY + innerHeight - 90
    })
    if (!c.length) c = words
    const w = c[(Math.random() * c.length) | 0]
    target = { x: w.x + w.w / 2, y: w.y + w.h / 2 }
  }

  const spawn = () => {
    if (!words.length) return
    const cx = scrollX + innerWidth / 2, cy = scrollY + innerHeight * 0.45
    let w = words[0], bd = Infinity
    for (const ww of words) {
      const d = Math.hypot(ww.x + ww.w / 2 - cx, ww.y + ww.h / 2 - cy)
      if (d < bd) { bd = d; w = ww }
    }
    Object.assign(body, { x: w.x + w.w / 2, y: w.y + w.h / 2, a: rnd(-0.6, 0.6), v: 0, w: 0 })
    dropAll()
    for (const l of legs) {
      l.L = LEG_L[l.k] * S
      const r = restAt(l, body)
      let fh: Hold | null = foothold(l, r, body)
      if (!fh) {
        let bd = Infinity
        for (const w of words) { const p = clampIn(w, r.x, r.y), dd = dist(p, r); if (dd < bd) { bd = dd; fh = { w, p } } }
      }
      if (!fh) continue
      l.x = fh.p.x; l.y = fh.p.y; l.state = "planted"; l.lift = 0
      l.el = fh.w.el; l.u = (fh.p.x - fh.w.x) / fh.w.w; l.v = (fh.p.y - fh.w.y) / fh.w.h
      l.slack = dist(fh.p, r) * 0.9
      grab(l.el, l.x, l.y)
    }
    pickTarget()
    mode = "walk"; modeT = rnd(20, 32); active = -1
    spawned = true
  }

  const fart = () => {
    if (mode === "fart" || !spawned) return
    mode = "fart"; modeT = 2.8; fartT = 0; gasOut = false; popped = false
  }

  const tail = (): P => {
    const c = Math.cos(body.a), s = Math.sin(body.a)
    return { x: body.x - c * 37 * S, y: body.y - s * 37 * S }
  }

  const update = (dt: number) => {
    // 3-minute silk cooldown timer
    if (silkCd > 0) {
      silkCd = Math.max(0, silkCd - dt)
      onSilkStatus?.(silkCd)
    }

    const menuOpen = ctl.current.menuOpen
    modeT -= dt
    const feeling = legs.some((l) => l.state === "feel")

    // ---------- silk swing mode ----------
    if (mode === "silk" && silk) {
      if (silk.phase === "shoot") {
        silk.t += dt
        silk.silkLen = Math.min(1, silk.t / silk.dur)
        const aim = Math.atan2(silk.anchor.y - body.y, silk.anchor.x - body.x)
        body.a += angDiff(aim, body.a) * Math.min(1, dt * 12)
        for (const l of legs) l.lift = Math.min(10 * S, l.lift + dt * 35)
        if (silk.t >= silk.dur) {
          silk.phase = "swing"
          silk.t = 0
          silk.dur = clamp(dist(silk.from, silk.to) / 420, 0.9, 1.6)
        }
      } else if (silk.phase === "swing") {
        silk.t += dt
        const p = Math.min(1, silk.t / silk.dur)
        const ep = smoother(p)
        const cx = silk.from.x + (silk.to.x - silk.from.x) * ep
        const cy = silk.from.y + (silk.to.y - silk.from.y) * ep + Math.sin(Math.PI * ep) * silk.arc
        const vx = cx - body.x, vy = cy - body.y
        body.x = cx; body.y = cy
        body.v = Math.hypot(vx, vy) / dt
        if (Math.hypot(vx, vy) > 2) body.a = Math.atan2(vy, vx)

        // Aerodynamic trailing legs in flight
        for (const l of legs) {
          const h = hipAt(l, body)
          const trailAng = body.a + Math.PI + l.side * (0.35 + l.k * 0.16)
          const len = l.L * 0.65
          l.x = h.x + Math.cos(trailAng) * len
          l.y = h.y + Math.sin(trailAng) * len
          l.lift = (12 + Math.sin(p * Math.PI) * 10) * S
        }

        // Spark particles along trajectory
        if (Math.random() < 0.7) {
          silk.sparks.push({
            x: body.x + rnd(-4, 4),
            y: body.y + rnd(-4, 4),
            vx: -Math.cos(body.a) * rnd(20, 70),
            vy: -Math.sin(body.a) * rnd(20, 70),
            t: 0,
            life: rnd(0.35, 0.7),
          })
        }

        if (p >= 1) {
          silk.phase = "land"
          silk.t = 0
          silk.dur = 0.22
        }
      } else if (silk.phase === "land") {
        silk.t += dt
        // Deploy and plant legs onto target word & neighbors
        if (silk.t >= silk.dur) {
          for (const l of legs) {
            l.L = LEG_L[l.k] * S
            const r = restAt(l, body)
            let fh = foothold(l, r, body)
            if (!fh) {
              let bd = Infinity
              for (const w of words) {
                const pt = clampIn(w, r.x, r.y), dd = dist(pt, r)
                if (dd < bd) { bd = dd; fh = { w, p: pt } }
              }
            }
            if (fh) {
              l.x = fh.p.x; l.y = fh.p.y; l.el = fh.w.el; l.u = (fh.p.x - fh.w.x) / fh.w.w; l.v = (fh.p.y - fh.w.y) / fh.w.h
              grab(l.el, l.x, l.y)
            } else {
              l.x = r.x; l.y = r.y; l.el = null
            }
            l.state = "planted"; l.lift = 0
          }
          silkCd = SILK_COOLDOWN
          onSilkStatus?.(silkCd)
          silk = null
          mode = "walk"
          modeT = rnd(12, 18)
          pickTarget()
        }
      }

      // Update spark particles
      if (silk) {
        for (let i = silk.sparks.length - 1; i >= 0; i--) {
          const spk = silk.sparks[i]
          spk.t += dt
          if (spk.t >= spk.life) { silk.sparks.splice(i, 1); continue }
          spk.x += spk.vx * dt
          spk.y += spk.vy * dt
        }
      }

      if (ctl.current.follow) {
        const want = body.y - innerHeight * 0.5
        scrollTo(scrollX, scrollY + (want - scrollY) * Math.min(1, dt * 3.5))
      }
      return
    }

    if (mode === "fart") {
      fartT += dt
      if (fartT > 0.32 && fartT < 0.62) {
        const burst = gasOut ? 1 : 16
        gasOut = true
        const tp = tail()
        for (let n = 0; n < burst; n++) {
          const ang = body.a + Math.PI + rnd(-0.65, 0.65), v = rnd(28, 92) * S
          gas.push({ x: tp.x, y: tp.y, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v, r: rnd(3, 6.5) * S, t: 0, life: rnd(1.1, 1.9) })
        }
      }
      if (fartT > 0.9 && !popped) {
        popped = true
        onFart(body.x - scrollX, body.y - scrollY)
        // Find news links on the page and select a random one to crawl to and click
        const newsLinks = [...root.querySelectorAll<HTMLElement>("[data-news-link]")]
        if (newsLinks.length > 0) {
          const chosen = newsLinks[(Math.random() * newsLinks.length) | 0]
          const r = chosen.getBoundingClientRect()
          const targetPos = { x: r.left + scrollX + r.width / 2, y: r.top + scrollY + r.height / 2 }
          huntingNews = { el: chosen, idx: Number(chosen.dataset.newsLink || 0), pos: targetPos }
          target = targetPos
          mode = "hunt-news"
          modeT = 20
        }
      }
      if (modeT <= 0 && mode === "fart") { mode = "pause"; modeT = 0.9 }
    } else if (menuOpen) {
      // Menu is open: spider must stop completely!
      body.v = 0
      body.w = 0
      mode = "pause"
      modeT = 99999
    } else if (modeT <= 0 && mode !== "hunt-news") {
      if (mode === "walk") { mode = "pause"; modeT = rnd(0.7, 1.6) }
      else if (!feeling) { mode = "walk"; modeT = rnd(8, 14); if (dist(body, target) < 60 || Math.random() < 0.5) pickTarget() }
    }

    // If target is far and silk cooldown has finished, trigger silk swing!
    if (mode === "walk" && silkCd <= 0 && dist(body, target) > 380) {
      let bestW: Word | null = null, bd = Infinity
      for (const w of words) {
        const dd = Math.hypot(w.x + w.w / 2 - target.x, w.y + w.h / 2 - target.y)
        if (dd < bd) { bd = dd; bestW = w }
      }
      if (bestW) { startSilkSwing(bestW); return }
    }

    // body steering
    let tv = 0, tw = 0
    if (mode === "walk" || mode === "hunt-news") {
      const dx = target.x - body.x, dy = target.y - body.y, d = Math.hypot(dx, dy)
      const da = angDiff(Math.atan2(dy, dx), body.a)
      const isHunt = mode === "hunt-news"
      tw = clamp(da * (isHunt ? 3.0 : 2.4), -2.0, 2.0)
      tv = SPEED * S * (isHunt ? 1.3 : 1) * clamp(d / 90, 0.3, 1) * Math.pow(Math.max(0, Math.cos(Math.min(Math.abs(da), 1.55))), 1.5)

      if (isHunt) {
        // When hunting news, viewport tracks spider to the news card
        if (ctl.current.follow) {
          const want = body.y - innerHeight * 0.5
          scrollTo(scrollX, scrollY + (want - scrollY) * Math.min(1, dt * 3.5))
        }
        if (d < 45 * S) {
          // Arrived at the news item: stop and click it on user behalf!
          mode = "pause"
          modeT = 2.5
          body.v = 0
          body.w = 0
          if (huntingNews) {
            const hn = huntingNews
            hn.el.classList.add("news-clicked")
            setTimeout(() => hn.el.classList.remove("news-clicked"), 3500)
            onNewsClicked?.(hn.idx, body.x - scrollX, body.y - scrollY)
            huntingNews = null
          }
        }
      } else if (d < 18) {
        if (Math.random() < 0.4) { mode = "pause"; modeT = rnd(0.7, 1.6) } else pickTarget()
      }
    }
    const probing = legs.some((l) => l.state === "swing" && l.seg < l.path.length - 1)
    let stretch = 1
    for (const l of legs)
      if (l.state === "planted") {
        const dh = dist(l, hipAt(l, body))
        stretch = Math.min(stretch, clamp((0.99 * l.L - dh) / (0.08 * l.L), 0.15, 1))
      }
    sf += ((probing ? 0.6 : feeling ? 0.3 : 1) * (0.05 + 0.95 * stretch) - sf) * Math.min(1, dt * 6)
    body.v += (tv * sf - body.v) * Math.min(1, dt * (mode === "fart" ? 9 : 2.6))
    body.w += (tw - body.w) * Math.min(1, dt * 3.5)
    body.a += body.w * dt * Math.min(sf, stretch)
    body.x += Math.cos(body.a) * body.v * dt
    body.y += Math.sin(body.a) * body.v * dt
    // Retract a telescoping leg once the body has caught up with its foothold.
    for (const l of legs) {
      const baseReach = LEG_L[l.k] * S
      if (l.state === "planted" && l.L > baseReach && dist(l, hipAt(l, body)) < 0.82 * baseReach)
        l.L += (baseReach - l.L) * Math.min(1, dt * 5)
    }
    if (stretch < 0.6) {
      let fx = 0, fy = 0, rx = 0, ry = 0, n = 0
      for (const l of legs)
        if (l.state === "planted") { const r = restAt(l, body); fx += l.x; fy += l.y; rx += r.x; ry += r.y; n++ }
      if (n) {
        const k = Math.min(1, dt * 4 * (1 - stretch / 0.6))
        body.x += ((fx - rx) / n) * k
        body.y += ((fy - ry) / n) * k
      }
    }

    // alternating tetrapod gait: only one diagonal group of four is ever in the air
    if (active >= 0 && legs.every((l) => l.group !== active || l.state === "planted")) { active = -1; gaitGap = 0.035 }
    gaitGap -= dt
    const busy = legs.some((l) => l.state !== "planted")
    if (active < 0 && !busy && gaitGap <= 0) {
      const walking = body.v > 3 || Math.abs(body.w) > 0.12
      const thr = walking ? 0.08 : 0.07
      const n = [0, 0]
      for (const l of legs) n[l.group] = Math.max(n[l.group], need(l))
      const alt = 1 - lastGroup
      let g = -1
      if (mode === "fart") g = n[alt] >= 9 ? alt : n[lastGroup] >= 9 ? lastGroup : -1
      else if (n[alt] > (walking ? thr * 0.55 : thr)) g = alt
      else if (n[lastGroup] > thr) g = lastGroup
      if (g >= 0) {
        const dur = clamp(0.18 - body.v * 0.00015, 0.13, 0.22)
        let any = false
        for (const l of legs) if (l.group === g && startStep(l, dur, STAGGER[l.k], thr * 0.25)) any = true
        if (any) active = g
        lastGroup = g
      }
    }

    // pause: feel ahead with a front leg
    feelCd -= dt
    if (mode === "pause" && !menuOpen && active < 0 && !legs.some((l) => l.state !== "planted") && body.v < 3 && feelCd <= 0) {
      feelSide = 1 - feelSide
      startFeel(legs[feelSide * 4])
      feelCd = rnd(1.0, 2.0)
    }

    updateLegs(dt)
    syncHeldWords()

    const ta = mode === "fart" ? 0.55 : mode === "pause" ? 0.42 : 0.12
    antAmp += (ta - antAmp) * Math.min(1, dt * 3)

    if (ctl.current.follow) {
      const want = body.y - innerHeight * 0.5
      scrollTo(scrollX, scrollY + (want - scrollY) * Math.min(1, dt * 2.5))
    }
  }

  // ---------- rendering ----------
  // Single-joint leg: hip -> knee -> tip.
  const solve = (l: Leg, hip: P, tip: P) => {
    const L = l.L, A = 0.47 * L, B = 0.53 * L
    const dx = tip.x - hip.x, dy = tip.y - hip.y, d = Math.hypot(dx, dy) || 1
    const ux = dx / d, uy = dy / d
    const dd = clamp(d, 0.2 * L, (A + B) * 0.995)
    const x = (A * A - B * B + dd * dd) / (2 * dd)
    const h = Math.sqrt(Math.max(0, A * A - x * x))
    // front pairs bow forward-out, rear pairs bow backward-out
    const sg = (l.k < 2 ? 1 : -1) * l.side
    return { knee: { x: hip.x + ux * x - uy * sg * h, y: hip.y + uy * x + ux * sg * h } }
  }

  const legGeo = (l: Leg) => {
    const hip = hipAt(l, body)
    const tip = { x: l.x, y: l.y - l.lift * 0.9 }
    return { hip, tip, ...solve(l, hip, tip) }
  }

  const seg = (a: P, b: P, w: number, c: string) => {
    ctx.strokeStyle = c; ctx.lineWidth = w
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke()
  }

  const ellipse = (x: number, y: number, rx: number, ry: number) => {
    ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2)
  }

  // High-tech square reticle for foot contact on text (visually matching the circle reticle)
  const drawTechSquare = (x: number, y: number, color: string, scale: number) => {
    const s = 3.4 * scale
    const tick = 2.0 * scale
    ctx.save()
    ctx.strokeStyle = color
    ctx.fillStyle = "#ffffff"
    ctx.lineWidth = 1.0 * scale
    ctx.shadowColor = color
    ctx.shadowBlur = 4 * scale

    // 1. Center circular pip (identical to circular reticle)
    ctx.beginPath(); ctx.arc(x, y, 1.2 * scale, 0, Math.PI * 2); ctx.fill()

    // 2. Outer square frame
    ctx.strokeRect(x - s, y - s, s * 2, s * 2)

    // 3. 4 cardinal crosshair ticks (N, S, W, E - identical to circular reticle)
    ctx.beginPath()
    ctx.moveTo(x, y - s - tick); ctx.lineTo(x, y - s)
    ctx.moveTo(x, y + s); ctx.lineTo(x, y + s + tick)
    ctx.moveTo(x - s - tick, y); ctx.lineTo(x - s, y)
    ctx.moveTo(x + s, y); ctx.lineTo(x + s + tick, y)
    ctx.stroke()

    ctx.restore()
  }

  // Small solid dot for whitespace probing (NO hollow circles on foot tip!)
  const drawTechDot = (x: number, y: number, scale: number, color = "#10e38a") => {
    ctx.save()
    ctx.fillStyle = color
    ctx.shadowColor = color
    ctx.shadowBlur = 4 * scale
    ctx.beginPath()
    ctx.arc(x, y, 2.0 * scale, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }

  // Breathing light: bright white normally, amber when the site reports an issue.
  let alertMix = 0
  const lightRGB = () => {
    const m = alertMix
    // Emerald green: rgb(14, 227, 135) -> Amber alert: rgb(255, 176, 32)
    const r = Math.round(14 + (255 - 14) * m)
    const g = Math.round(227 + (176 - 227) * m)
    const b = Math.round(135 + (32 - 135) * m)
    return `${r},${g},${b}`
  }

  const render = (now: number, dt: number) => {
    const t = now / 1000
    alertMix += ((ctl.current.alert ? 1 : 0) - alertMix) * Math.min(1, dt * 3)
    const b = breath(t * (1 + alertMix * 0.6))
    const C = lightRGB()
    const glowC = `rgb(${C})`
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0)
    ctx.clearRect(0, 0, innerWidth, innerHeight)
    ctx.translate(-scrollX, -scrollY)
    ctx.lineCap = "round"; ctx.lineJoin = "round"
    const geos = legs.map(legGeo)

    // soft ground shadow
    ctx.save()
    ctx.translate(4 * S, 7 * S)
    ctx.strokeStyle = "rgba(8,20,30,0.07)"; ctx.lineWidth = 1.4 * S
    legs.forEach((l, i) => {
      const g = geos[i]
      ctx.beginPath(); ctx.moveTo(g.hip.x, g.hip.y); ctx.lineTo(g.knee.x, g.knee.y); ctx.lineTo(l.x, l.y); ctx.stroke()
    })
    ctx.translate(body.x, body.y); ctx.rotate(body.a); ctx.scale(S, S)
    ctx.fillStyle = "rgba(8,20,30,0.08)"
    ellipse(-17, 0, 21, 15); ctx.fill(); ellipse(11, 0, 13, 10.5); ctx.fill()
    ctx.fillStyle = "rgba(8,20,30,0.08)"
    ellipse(-17, 0, 18, 12); ctx.fill(); ellipse(11, 0, 10.5, 8); ctx.fill()
    ctx.restore()

    // ---------- glowing spider silk rendering ----------
    if (silk) {
      const sp = tail()
      const curTip = {
        x: sp.x + (silk.anchor.x - sp.x) * silk.silkLen,
        y: sp.y + (silk.anchor.y - sp.y) * silk.silkLen,
      }
      const midX = (sp.x + curTip.x) / 2
      const midY = (sp.y + curTip.y) / 2 + Math.min(22, dist(sp, curTip) * 0.04)

      // Silk outer halo
      ctx.strokeStyle = "rgba(40, 240, 170, 0.45)"
      ctx.lineWidth = 3 * S
      ctx.beginPath(); ctx.moveTo(sp.x, sp.y); ctx.quadraticCurveTo(midX, midY, curTip.x, curTip.y); ctx.stroke()

      // Silk intense core
      ctx.strokeStyle = "rgba(255, 255, 255, 0.95)"
      ctx.lineWidth = 1.2 * S
      ctx.beginPath(); ctx.moveTo(sp.x, sp.y); ctx.quadraticCurveTo(midX, midY, curTip.x, curTip.y); ctx.stroke()

      // Anchor node ping
      if (silk.silkLen >= 0.95) {
        ctx.strokeStyle = "rgba(40, 240, 170, 0.9)"
        ctx.lineWidth = 1.2
        ctx.beginPath(); ctx.arc(silk.anchor.x, silk.anchor.y, 5 * S, 0, Math.PI * 2); ctx.stroke()
        ctx.fillStyle = "#ffffff"
        ctx.beginPath(); ctx.arc(silk.anchor.x, silk.anchor.y, 1.8 * S, 0, Math.PI * 2); ctx.fill()
      }

      // Spark particles
      for (const spk of silk.sparks) {
        const alpha = Math.max(0, 1 - spk.t / spk.life)
        ctx.fillStyle = `rgba(100, 255, 200, ${alpha * 0.8})`
        ctx.beginPath(); ctx.arc(spk.x, spk.y, 1.2 * S, 0, Math.PI * 2); ctx.fill()
      }
    }

    // probe radar ripples on blank whitespace
    for (let r = ripples.length - 1; r >= 0; r--) {
      const rp = ripples[r]
      rp.t += dt / 0.65
      if (rp.t >= 1) { ripples.splice(r, 1); continue }
      const p = rp.t
      const rad = (3.5 + p * 22) * S
      const alpha = (1 - p) * 0.75

      ctx.save()
      ctx.strokeStyle = `rgba(16, 227, 138, ${alpha})`
      ctx.lineWidth = 1.0 * S
      ctx.shadowColor = "rgba(16, 227, 138, 0.6)"
      ctx.shadowBlur = 4 * S

      // Primary expanding circle ring
      ctx.beginPath(); ctx.arc(rp.x, rp.y, rad, 0, Math.PI * 2); ctx.stroke()

      // Inner concentric sonar circle ring
      if (p < 0.7) {
        ctx.strokeStyle = `rgba(16, 227, 138, ${alpha * 0.55})`
        ctx.beginPath(); ctx.arc(rp.x, rp.y, rad * 0.55, 0, Math.PI * 2); ctx.stroke()
      }

      // Dashed outer radar ring
      ctx.setLineDash([2.5 * S, 3.5 * S])
      ctx.strokeStyle = `rgba(117, 138, 153, ${alpha * 0.5})`
      ctx.beginPath(); ctx.arc(rp.x, rp.y, rad * 1.25, 0, Math.PI * 2); ctx.stroke()
      ctx.setLineDash([])

      // 4 crosshair ticks
      ctx.strokeStyle = `rgba(16, 227, 138, ${alpha * 0.7})`
      ctx.beginPath()
      ctx.moveTo(rp.x - rad - 2 * S, rp.y); ctx.lineTo(rp.x - rad + 2 * S, rp.y)
      ctx.moveTo(rp.x + rad - 2 * S, rp.y); ctx.lineTo(rp.x + rad + 2 * S, rp.y)
      ctx.moveTo(rp.x, rp.y - rad - 2 * S); ctx.lineTo(rp.x, rp.y - rad + 2 * S)
      ctx.moveTo(rp.x, rp.y + rad - 2 * S); ctx.lineTo(rp.x, rp.y + rad + 2 * S)
      ctx.stroke()

      // Center flash dot at start
      if (p < 0.3) {
        ctx.fillStyle = `rgba(255, 255, 255, ${(0.3 - p) / 0.3 * 0.9})`
        ctx.beginPath(); ctx.arc(rp.x, rp.y, 1.8 * S, 0, Math.PI * 2); ctx.fill()
      }
      ctx.restore()
    }

    // legs: thin graphite struts with a neon core, one knee joint
    legs.forEach((l, i) => {
      const g = geos[i]
      ctx.strokeStyle = "#1a2731"; ctx.lineWidth = 1.7 * S
      ctx.beginPath(); ctx.moveTo(g.hip.x, g.hip.y); ctx.lineTo(g.knee.x, g.knee.y); ctx.lineTo(g.tip.x, g.tip.y); ctx.stroke()
      ctx.strokeStyle = "rgba(40,240,170,0.85)"; ctx.lineWidth = 0.55
      ctx.beginPath(); ctx.moveTo(g.hip.x, g.hip.y); ctx.lineTo(g.knee.x, g.knee.y); ctx.lineTo(g.tip.x, g.tip.y); ctx.stroke()
      // knee joint
      ctx.fillStyle = "#0e161c"; ctx.beginPath(); ctx.arc(g.knee.x, g.knee.y, 1.9 * S, 0, Math.PI * 2); ctx.fill()
      ctx.strokeStyle = "rgba(40,240,170,0.9)"; ctx.lineWidth = 0.7; ctx.stroke()

      if (l.state === "planted") {
        // Planted foot is ALWAYS on a word
        const col = held.get(l.el!)?.color ?? "#0aa344"
        drawTechSquare(l.x, l.y, col, S)
      } else if (l.state === "swing") {
        // In-flight whitespace tap: directly a small solid dot (no hollow circle!)
        const curWp = l.path[l.seg]
        if (curWp?.tap && l.lift < 3.2 * S) {
          drawTechDot(l.x, l.y, S, "#10e38a")
        }
      } else if (l.state === "feel") {
        if (l.lift < 2.5 * S) {
          drawTechDot(l.x, l.y, S, "#10e38a")
        }
      }
    })

    // body
    ctx.save()
    ctx.translate(body.x, body.y); ctx.rotate(body.a); ctx.scale(S, S)

    const glow = ctx.createRadialGradient(-6, 0, 4, -6, 0, 58)
    glow.addColorStop(0, `rgba(${C},${0.1 + 0.3 * b})`)
    glow.addColorStop(1, `rgba(${C},0)`)
    ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(-6, 0, 58, 0, Math.PI * 2); ctx.fill()

    // antennae
    for (const sd of [-1, 1]) {
      const fA = antAmp > 0.3 ? 3.2 : 9
      const a1 = sd * 0.42 + Math.sin(t * fA + sd * 1.7) * antAmp
      const p0 = { x: 21.5, y: sd * 2.8 }
      const p1 = { x: p0.x + Math.cos(a1) * 8, y: p0.y + Math.sin(a1) * 8 }
      const a2 = a1 - sd * 0.28 + Math.sin(t * fA * 1.3 + sd) * antAmp * 0.7
      const p2 = { x: p1.x + Math.cos(a2) * 7, y: p1.y + Math.sin(a2) * 7 }
      seg(p0, p1, 0.9, "#1a2731"); seg(p1, p2, 0.7, "#1a2731")
      ctx.shadowColor = glowC; ctx.shadowBlur = 6
      ctx.fillStyle = `rgba(${C},${0.6 + 0.4 * b})`; ctx.beginPath(); ctx.arc(p2.x, p2.y, 1.2, 0, Math.PI * 2); ctx.fill()
      ctx.shadowBlur = 0
    }

    // abdomen (squeezes during the fart)
    let sq = 0
    if (mode === "fart") sq = fartT < 0.32 ? fartT / 0.32 : Math.exp(-(fartT - 0.32) * 6) * Math.cos((fartT - 0.32) * 20)
    ctx.save()
    ctx.translate(-17, 0); ctx.scale(1 - 0.13 * sq, 1 + 0.07 * sq)
    const ag = ctx.createLinearGradient(0, -13, 0, 13)
    ag.addColorStop(0, "#3a4a56"); ag.addColorStop(0.5, "#16212a"); ag.addColorStop(1, "#0a1117")
    ctx.fillStyle = ag; ellipse(0, 0, 19, 13); ctx.fill()
    // hex-panel seams
    ctx.strokeStyle = "rgba(140,170,190,0.18)"; ctx.lineWidth = 0.5
    for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(-16, sd * 5); ctx.lineTo(-6, sd * 9); ctx.lineTo(8, sd * 9); ctx.lineTo(16, sd * 5); ctx.stroke() }
    // rim light
    ctx.shadowColor = glowC; ctx.shadowBlur = 4 + 14 * b
    ctx.strokeStyle = `rgba(${C},${0.35 + 0.6 * b})`; ctx.lineWidth = 0.9 + 0.4 * b
    ellipse(0, 0, 19, 13); ctx.stroke()
    // dorsal breathing line: halo, glow, core
    ctx.shadowBlur = 0
    seg({ x: -15, y: 0 }, { x: 15, y: 0 }, 5 + 7 * b, `rgba(${C},${0.08 + 0.22 * b})`)
    ctx.shadowColor = glowC
    ctx.shadowBlur = 6 + 22 * b
    seg({ x: -15, y: 0 }, { x: 15, y: 0 }, 2.2 + 1.6 * b, `rgba(${C},${0.45 + 0.55 * b})`)
    const coreC = alertMix > 0.4 ? "255,250,225" : "195,255,225"
    seg({ x: -14, y: 0 }, { x: 14, y: 0 }, 0.9 + 0.6 * b, `rgba(${coreC},${0.65 + 0.35 * b})`)
    // chevrons light up in a wave from tail to waist
    ;[-9, -2, 5].forEach((cx, n) => {
      const bi = breath(t - (2 - n) * 0.2)
      ctx.shadowColor = glowC
      ctx.shadowBlur = 3 + 14 * bi
      ctx.strokeStyle = `rgba(${C},${0.2 + 0.8 * bi})`; ctx.lineWidth = 0.7 + 0.5 * bi
      for (const sd of [-1, 1]) { ctx.beginPath(); ctx.moveTo(cx - 4, sd * 8.5); ctx.lineTo(cx + 2, sd * 3); ctx.stroke() }
    })
    ctx.shadowBlur = 0
    ctx.restore()

    // pedicel + cephalothorax
    ctx.fillStyle = "#0e161c"; ellipse(0.5, 0, 3, 3.2); ctx.fill()
    const cg = ctx.createLinearGradient(0, -9, 0, 9)
    cg.addColorStop(0, "#3a4a56"); cg.addColorStop(0.55, "#16212a"); cg.addColorStop(1, "#0a1117")
    ctx.fillStyle = cg; ellipse(11, 0, 11.5, 8.8); ctx.fill()
    ctx.strokeStyle = `rgba(${C},${0.35 + 0.4 * b})`; ctx.lineWidth = 0.6; ellipse(11, 0, 11.5, 8.8); ctx.stroke()
    ctx.shadowColor = glowC; ctx.shadowBlur = 4 + 14 * b
    seg({ x: 4, y: 0 }, { x: 14, y: 0 }, 0.9 + 0.6 * b, `rgba(${C},${0.45 + 0.55 * b})`)
    ctx.shadowBlur = 0
    // visor eyes
    ctx.shadowColor = "#28f0aa"; ctx.shadowBlur = 6
    ctx.fillStyle = "#7affd0"
    for (const [ex, ey, er] of [[19, 2.3, 1.4], [19, -2.3, 1.4], [16.8, 4.4, 0.9], [16.8, -4.4, 0.9]]) {
      ctx.beginPath(); ctx.arc(ex, ey, er, 0, Math.PI * 2); ctx.fill()
    }
    ctx.restore()
    ctx.shadowBlur = 0

    // gas
    for (let n = gas.length - 1; n >= 0; n--) {
      const p = gas[n]
      p.t += dt
      if (p.t >= p.life) { gas.splice(n, 1); continue }
      const damp = Math.exp(-2.2 * dt)
      p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= damp; p.vy *= damp
      const k = p.t / p.life, r = p.r + k * 18 * S
      const a = 0.5 * Math.pow(1 - k, 1.2) * Math.min(1, p.t * 8)
      const gg = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r)
      gg.addColorStop(0, `rgba(176,198,104,${a})`); gg.addColorStop(1, "rgba(176,198,104,0)")
      ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill()
    }
  }

  // ---------- loop ----------
  let raf = 0, last = performance.now(), wasOn = true, acc = 0
  const loop = (now: number) => {
    raf = requestAnimationFrame(loop)
    const dt = Math.min(0.25, Math.max(0, (now - last) / 1000))
    last = now
    const on = ctl.current.enabled
    if (!on) {
      if (wasOn) { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, canvas.width, canvas.height); dropAll(); spawned = false }
      wasOn = false
      return
    }
    wasOn = true
    if (!spawned) { if (!words.length) measure(); spawn(); if (!spawned) return }
    acc += dt
    while (acc >= STEP_H) { update(STEP_H); acc -= STEP_H }
    render(now, dt)
  }

  measure()
  addEventListener("resize", measure)
  document.fonts?.ready.then(measure)
  raf = requestAnimationFrame(loop)

  // ---------- interaction ----------
  const hit = (x: number, y: number) => {
    if (!ctl.current.enabled || !spawned) return false
    const c = Math.cos(body.a), s = Math.sin(body.a)
    return Math.hypot(x + scrollX - (body.x - c * 6 * S), y + scrollY - (body.y - s * 6 * S)) < 36 * S
  }
  const isUi = (e: Event) => (e.target as HTMLElement)?.closest?.("[data-ui]")
  let clickTimer = 0, pressTimer = 0, suppress = false, menuAtDown = false, downAt: P = { x: 0, y: 0 }
  const onDown = (e: PointerEvent) => {
    menuAtDown = ctl.current.menuOpen
    downAt = { x: e.clientX, y: e.clientY }
    if (e.pointerType !== "mouse" && hit(e.clientX, e.clientY) && !isUi(e))
      pressTimer = window.setTimeout(() => { suppress = true; clearTimeout(clickTimer); fart() }, 480)
  }
  const onMove = (e: PointerEvent) => {
    if (Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 10) clearTimeout(pressTimer)
    if (e.pointerType === "mouse") document.documentElement.style.cursor = hit(e.clientX, e.clientY) && !isUi(e) ? "pointer" : ""
  }
  const onUp = () => clearTimeout(pressTimer)
  const onClick = (e: MouseEvent) => {
    if (suppress) { suppress = false; return }
    if (menuAtDown || isUi(e) || !hit(e.clientX, e.clientY)) return
    clearTimeout(clickTimer)
    const { clientX: x, clientY: y } = e
    clickTimer = window.setTimeout(() => {
      // Spider stops immediately when clicked!
      body.v = 0
      body.w = 0
      mode = "pause"
      modeT = 99999
      onMenu(x, y)
    }, 240)
  }
  const onDbl = (e: MouseEvent) => {
    if (isUi(e) || !hit(e.clientX, e.clientY)) return
    clearTimeout(clickTimer)
    fart()
  }
  const onCtx = (e: MouseEvent) => { if (hit(e.clientX, e.clientY)) e.preventDefault() }
  addEventListener("pointerdown", onDown, true)
  addEventListener("pointermove", onMove)
  addEventListener("pointerup", onUp)
  addEventListener("pointercancel", onUp)
  addEventListener("click", onClick)
  addEventListener("dblclick", onDbl)
  addEventListener("contextmenu", onCtx)

  return () => {
    cancelAnimationFrame(raf)
    clearTimeout(clickTimer); clearTimeout(pressTimer)
    removeEventListener("resize", measure)
    removeEventListener("pointerdown", onDown, true)
    removeEventListener("pointermove", onMove)
    removeEventListener("pointerup", onUp)
    removeEventListener("pointercancel", onUp)
    removeEventListener("click", onClick)
    removeEventListener("dblclick", onDbl)
    removeEventListener("contextmenu", onCtx)
    document.documentElement.style.cursor = ""
    dropAll()
  }
}
